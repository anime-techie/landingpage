import React, { Component } from 'react';

class Infomation extends Component {
    render() {
        return (
            <section>
            <div className="container">
              <div className="row">
                <div className="col-lg-4 col-md-4">
                  <h5><span className="text-theme font-w-7">01.</span> Work From Home</h5>
                  <p>Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model infancy.</p>
                </div>
                <div className="col-lg-4 col-md-4">
                  <h5><span className="text-theme font-w-7">02.</span> Office An Great Location</h5>
                  <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia Neque porro est.</p>
                </div>
                <div className="col-lg-4 col-md-4">
                  <h5><span className="text-theme font-w-7">03.</span> Shared Success</h5>
                  <p>Officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et non recusandae.</p>
                </div>
                <div className="col-lg-4 col-md-4">
                  <h5><span className="text-theme font-w-7">04.</span> Medical insurance</h5>
                  <p>Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model infancy.</p>
                </div>
                <div className="col-lg-4 col-md-4">
                  <h5><span className="text-theme font-w-7">05.</span> Regular Reviews</h5>
                  <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia Neque porro est.</p>
                </div>
                <div className="col-lg-4 col-md-4">
                  <h5><span className="text-theme font-w-7">06.</span> Bonus Available</h5>
                  <p>Officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et non recusandae.</p>
                </div>
              </div>
            </div>
          </section>
       
        );
    }
}

export default Infomation;