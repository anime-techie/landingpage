/**
 *  Main Menu Json
 */
 export default [
    {
        "menu_title": "How it works",
        "path": "/how-it-works",
        "icon": "home",
     },
    {
        "menu_title": "FAQs",
        "path": "/seller-faq",
        "icon": "home",
     },
    {
       "menu_title": "Sign In",
       "path": "https://seller.rebatecube.com/signin",
       "icon": "home",
    }
 ]
 