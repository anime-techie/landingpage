// import '../styles/globals.css';
import 'react-accessible-accordion/dist/fancy-example.css';
import 'react-modal-video/css/modal-video.css';

function MyApp({ Component, pageProps }) {
	return <Component {...pageProps} />;
}

export default MyApp;
