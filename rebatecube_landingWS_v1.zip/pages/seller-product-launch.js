import React, { Component } from 'react';
// import Testing from '../widgets/testing';
import Herosection6 from '../widgets/herosection/herosection6';
import Feature2 from '../widgets/featurebox/feature';
// import OwlCarousel from 'react-owl-carousel';
import Pricingplan4 from '../widgets/pricingplan/pricingplan4';
import Worktab from '../widgets/featuare/worktab';
import Header2 from '../layout/header/header2';
import dynamic from 'next/dynamic';
import Testing from '../widgets/Testing';
// const Testing = dynamic(() => import('../widgets/Testing'));
// class Index7 extends Component {
// 	render() {
// 		return <Testing />;
// 	}
// }
const Seller = () => {
	return <Testing />;
};

export default Seller;
